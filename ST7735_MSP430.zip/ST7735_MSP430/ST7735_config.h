/*
 * ST7735_config.h
 *
 *  Created on: Jun 23, 2017
 *      Author: JJH
 *
 *    LCD connections to the MSP430:
 *      lcd reset  P1.4
 *      lcd chip select  P1.5
 *      A0  P1.3
 *      SCLK  P1.1
 *      SDA   P1.2
 *      backlight P1.0
 */

#ifndef ST7735_CONFIG_H_
#define ST7735_CONFIG_H_


// #define RED_BLUE_REVERSE

#define LCD_RESET_OUTPORT   P1OUT
#define LCD_RESET_DIRPORT   P1DIR
#define LCD_RESET_BIT_NUM   4
#define LCD_RESET_BIT_MASK  (1 << LCD_RESET_BIT_NUM)

#define LCD_CS_OUTPORT   P1OUT
#define LCD_CS_DIRPORT   P1DIR
#define LCD_CS_BIT_NUM   5
#define LCD_CS_BIT_MASK  (1 << LCD_CS_BIT_NUM)

#define LCD_A0_OUTPORT  P1OUT
#define LCD_A0_DIRPORT  P1DIR
#define LCD_A0_BIT_NUM  3
#define LCD_A0_BIT_MASK (1 << LCD_A0_BIT_NUM)

#define LCD_SCLK_OUTPORT  P1OUT
#define LCD_SCLK_DIRPORT  P1DIR
#define LCD_SCLK_BIT_NUM  1
#define LCD_SCLK_BIT_MASK (1 << LCD_SCLK_BIT_NUM)

#define LCD_SDA_OUTPORT   P1OUT
#define LCD_SDA_DIRPORT   P1DIR
#define LCD_SDA_BIT_NUM   2
#define LCD_SDA_BIT_MASK  (1 << LCD_SDA_BIT_NUM)

#define BACKLITE_OUTPORT   P1OUT
#define BACKLITE_DIRPORT   P1DIR
#define BACKLITE_BIT_NUM   0
#define BACKLITE_BIT_MASK  (1 << BACKLITE_BIT_NUM)

#endif /* ST7735_CONFIG_H_ */
