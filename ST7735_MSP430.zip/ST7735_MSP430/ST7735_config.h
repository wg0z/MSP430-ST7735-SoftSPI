/*
 * ST7735_config.h
 *
 *  Created on: Jun 23, 2017
 *      Author: JJH
 *
 *    'standard'connections:
 *      lcd reset P1.7
 *      lcd chip select P1.6
 *      A0 P1.5
 *      SCLK P1.4
 *      SDA  P1.3
 */

#ifndef ST7735_CONFIG_H_
#define ST7735_CONFIG_H_


#define LCD_RESET_OUTPORT   P1OUT
#define LCD_RESET_DIRPORT   P1DIR
#define LCD_RESET_PIN_NUM   7
#define LCD_RESET_PIN_MASK  (1 << LCD_RESET_PIN_NUM)

#define LCD_CS_OUTPORT   P1OUT
#define LCD_CS_DIRPORT   P1DIR
#define LCD_CS_PIN_NUM   6
#define LCD_CS_PIN_MASK  (1 << LCD_CS_PIN_NUM)

#define LCD_A0_OUTPORT  P1OUT
#define LCD_A0_DIRPORT  P1DIR
#define LCD_A0_PIN_NUM  5
#define LCD_A0_PIN_MASK (1 << LCD_A0_PIN_NUM)

#define LCD_SCLK_OUTPORT  P1OUT
#define LCD_SCLK_DIRPORT  P1DIR
#define LCD_SCLK_PIN_NUM  4
#define LCD_SCLK_PIN_MASK (1 << LCD_SCLK_PIN_NUM)

#define LCD_SDA_OUTPORT   P1OUT
#define LCD_SDA_DIRPORT   P1DIR
#define LCD_SDA_PIN_NUM   3
#define LCD_SDA_PIN_MASK  (1 << LCD_SDA_PIN_NUM)


#endif /* ST7735_CONFIG_H_ */
