/*
 * ST7735_named_numbers.h
 *
 *  Created on: Jun 23, 2017
 *      Author: JJ Hastings WG0Z
 */

#ifndef ST7735_NAMED_NUMBERS_H_
#define ST7735_NAMED_NUMBERS_H_

#define NOP         0x00
#define SW_RESET    0x01
#define SLEEP_OUT   0x11
#define DISPLAY_ON  0x29
#define CA_SET      0x2A
#define RA_SET      0x2B
#define RAM_WRITE   0x2C
#define COLOR_MODE  0x3A


#endif /* ST7735_NAMED_NUMBERS_H_ */
