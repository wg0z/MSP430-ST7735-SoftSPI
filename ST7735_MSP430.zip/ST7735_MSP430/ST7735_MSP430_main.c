//***************************************************************************************
//  ST7735_MSP430_main.c
//  Software/bit-bang SPI interface to ST7735(R) : demo for low-end MSP430 devices
//  developed using an MSP430G2211 on an MSP-EXP430G2 launchpad  6/2017
//  SPI LCD -> 1.44" ( 1 inch square) LCD, 128x128 pixels
//
//  J J Hastings WG0Z
//
//  port/usage guide:
//     1) the config header file has 5 blocks of macros/symbol defines
//        each block is 4 lines
//        users should set the first 3 defines of each block as required to match
//        the exact wiring interconnections used

//     2) adjust pause() function as required to yield a few hundred
//        milliseconds worth of delay

//     3) Color parameter as used in draw is 32 bits:
//        uppermost byte unused, upper-middle byte red,
//        lower-middle byte green, lowermost byte blue

//        turn on RED_BLUE_REVERSE macro in config header if your display
//        has those colors reversed;
//        this demo in and of itself is immune to the problem

//        only the upper 6 bits of each of the three meaningful color bytes have any meaning
//        see section 9.7.22 (or 9.8.22) of the Sitronix
//        ST7735 (or ST7735R) datasheet

//     4) to draw a single pixel, call draw() with both width and height set to 1
//        width OR height of zero will not result in any draw action
//
//
//***************************************************************************************

#include <msp430.h>

#include "ST7735_prototypes.h"



const unsigned long demoPal [ 7 ] = {
   // seven meaningful color codes - BLU GREEN CYAN RED MAUVE YELLOW WHITE
   0xFFL, 0xFF00L, 0xFFFFL, 0xFF00000L, 0xFF00FFL, 0xFFFF00L, 0xFFFFFFL };
#define INDEX_MODULUS (sizeof(demoPal) / sizeof(demoPal[0]))


unsigned ColorIndex;  // points into demoPallete[]
unsigned square_num, offset;



int main(void) {

    WDTCTL = WDTPW | WDTHOLD;		// Stop watchdog timer
	P1DIR |= 0x01;					// Set P1.0 to output direction - launchpad LED

	// DCO calibration
	DCOCTL = 0;             // Select lowest DCOx and MODx settings
	BCSCTL1 = CALBC1_1MHZ;  // Set range
	DCOCTL = CALDCO_1MHZ;   // Set DCO step + modulation */


    ST7735_if_init();
    ST7735_display_init();


    // clear the screen by writing zero to all parts of the 7735's display memory
    // the actual display used may not be 132x160, could just be (as an example) 128x128
    draw(0, 0, 132, 162, 0L);

    // now just loop forever -
    // draw 6 squares, each using one of the 7 meaningful primary colors
    // the color pattern of the squares will change as time passes
    // because 6 != 7
    for (;;)
    {
      for(square_num = 6; square_num >= 1; square_num--)
      {
        offset = 10 * square_num;
        draw( 64 - offset, 64 - offset, offset*2, offset*2, demoPal[ColorIndex]);
        ColorIndex = (ColorIndex + 1 ) % INDEX_MODULUS;
      } // end for square_num 6..1

    } // end for(ever)
}
