//***************************************************************************************
//  ST7735_MSP430_main.c
//  Software/bit-bang SPI interface to ST7735(R) : demo for low-end MSP430 devices
//  developed using an MSP430G2211 on an MSP-EXP430G2 launchpad  6/2017
//  SPI LCD -> 1.44" ( 1 inch square) LCD, 128x128 pixels
//
//  J J Hastings WG0Z
//
//  port/usage guide:
//     1) the config header file has several 4 blocks of macros/symbol defines
//        each block is 4 lines
//        users should set the first 3 defines of each block as required to match
//        the exact wiring interconnections used
//     2) adjust pause() function as required to yield a few hundred
//        milliseconds worth of delay
//     3) Color parameter as used in drawPixel is 32 bits:
//        uppermost byte unused, upper-middle byte red,
//        lower-middle byte green, lowermost byte blue
//        only the upper 6 bits of the color bytes have any meaning
//        see section 9.7.22 (or 9.8.22) of the Sitronix
//        ST7735 (or ST7735R) datasheet
//     4) to draw a single pixel, call draw() with both width and height set to 1
//        width OR height of zero will not result in any draw action
//
//
//***************************************************************************************

#include <msp430.h>

// #include "ST7735_config.h"
#include "ST7735_prototypes.h"

int main(void) {



    WDTCTL = WDTPW | WDTHOLD;		// Stop watchdog timer
	P1DIR |= 0x01;					// Set P1.0 to output direction


    ST7735_if_init();
    ST7735_display_init();


    // draw a 7x7 GREEN square
    draw( 25, 25, 7, 7, 0xFF00L);

    // draw a 10x10 white square
    draw( 55, 55, 10, 10, 0xFFFFFFL);

	// now just toggle the LED forever
	for(;;)
	{
		P1OUT ^= 0x01;  // Toggle P1.0 using exclusive-OR
		pause();
	}
	
	// return 0;
}
