/*
 * ST7735_primitives.c
 *
 *      Author: JJ Hastings WG0Z
 */


#include "msp430.h"
#include "ST7735_named_numbers.h"
#include "ST7735_config.h"
#include "ST7735_prototypes.h"



#define SELECT_L    LCD_CS_OUTPORT &= ~LCD_CS_PIN_MASK  // active-LOW signal
#define DESELECT    LCD_CS_OUTPORT |= LCD_CS_PIN_MASK
#define SDA_LO      LCD_SDA_OUTPORT &= ~LCD_SDA_PIN_MASK
#define SDA_HI      LCD_SDA_OUTPORT |= LCD_SDA_PIN_MASK
#define SCLK_HI     LCD_SCLK_OUTPORT |= LCD_SCLK_PIN_MASK
#define SCLK_LO     LCD_SCLK_OUTPORT &= ~LCD_SCLK_PIN_MASK
#define DATA        LCD_A0_OUTPORT |= LCD_A0_PIN_MASK    // pin HIGH
#define COMMAND     LCD_A0_OUTPORT &= ~LCD_A0_PIN_MASK   // pin LOW
#define RESET_L     LCD_RESET_OUTPORT &= ~LCD_RESET_PIN_MASK // active-LOW signal
#define RUN         LCD_RESET_OUTPORT |= LCD_RESET_PIN_MASK

// SDA can be output or input pin
#define SEND        LCD_SDA_DIRPORT   |= LCD_SDA_PIN_MASK;
#define RVC         LCD_SDA_DIRPORT   &= ~LCD_SDA_PIN_MASK;


// data[] is used by draw()
static unsigned char data[4];

void sendByte( unsigned char item)
{
    unsigned char mask = 0x80;

    do
    {
        if (mask & item)
          { SDA_HI; }
        else
          { SDA_LO; }
        SCLK_HI;
        SCLK_LO;
        mask >>= 1;

    } while (mask);
}



void ST7735_command( unsigned char cmd)
{
    COMMAND;
    SELECT_L;
    sendByte( cmd );
    DESELECT;
}



void ST7735_data(unsigned char * pValues, unsigned char cnt)
{

    // abort if cnt is zero for some reason
    if (0==cnt) return;

    DATA;
    SELECT_L;
    do
    {
      sendByte( *pValues );
      pValues++;
      cnt--;
    } while (cnt);
    DESELECT;
}


// FUNCTIONS BELOW ARE 'PUBLIC' and
// defined in ST7735_prototypes.h


void pause( void )
{
    // for MSP430G2 launchpad,
    // 30000 yields about a quarter-second of delay.
    volatile unsigned ix = 30000;
    do
    {
      ix--;
    } while ( 0 != ix);
}


void ST7735_if_init( void )
{
  // configure the pins for LCD reset, CS, a0, sclk as outputs
  LCD_RESET_DIRPORT |= LCD_RESET_PIN_MASK;
  LCD_CS_DIRPORT    |= LCD_CS_PIN_MASK;
  LCD_A0_DIRPORT    |= LCD_A0_PIN_MASK;
  LCD_SCLK_DIRPORT  |= LCD_SCLK_PIN_MASK;

  // configure SDA as an output
  // for this pin, SEND and RCV control the direction
  SEND;

  // reset LCD
  // deselect LCD
  // initialize A0, SCLK, SDA to LOW
  RESET_L;
  DESELECT;
  COMMAND;
  SCLK_LO;
  SDA_LO;

  // make sure reset is ACTIVE for a few hundred ms
  pause();

  // TAKE LCD OUT OF RESET
  RUN;

  // give the LCD time to complete the RESET actions
  pause();

}


void ST7735_display_init( void )
{
  ST7735_command( SW_RESET );
  pause();
  ST7735_command( SLEEP_OUT );
  pause();
  ST7735_command( DISPLAY_ON );
}


void draw( unsigned char x, unsigned char y,
           unsigned char width, unsigned char height,
           unsigned long Color)
{
    unsigned num_pixels = width * height;

    // abort if the region size is zero
    if (0==num_pixels) return;

    // data[0] and [2] will always be zero for both
    // the CA_set and the RA_set commands
    data[0] = 0;
    data[2] = 0;

    data[1] = x;
    data[3] = x + width - 1;
    ST7735_command( CA_SET );
    ST7735_data( data, 4 );

    data[1] = y;
    data[3] = y + height - 1;
    ST7735_command( RA_SET );
    ST7735_data( data, 4 );

    ST7735_command( RAM_WRITE );
    data[0] = (unsigned char)(Color >> 16);
    data[1] = (unsigned char)(Color >> 8);
    data[2] = (unsigned char)Color;
    // data[4] is don't-care for the display RAM writes

    // write 3 bytes to the display RAM for each pixel
    do {
      ST7735_data( data, 3  );
      num_pixels--;
    } while (0 != num_pixels);

    // force an end to the display RAM writes
    ST7735_command( NOP );
}

