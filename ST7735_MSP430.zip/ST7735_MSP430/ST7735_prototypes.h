/*
 * ST7735_prototypes.h
 *
 *  Created on: Jun 23, 2017
 *      Author: JJH
 */

#ifndef ST7735_PROTOTYPES_H_
#define ST7735_PROTOTYPES_H_

void pause( void );
void ST7735_if_init( void );
void ST7735_display_init( void );
void draw( unsigned char x, unsigned char y,
           unsigned char width, unsigned char height,
           unsigned long Color);

#endif /* ST7735_PROTOTYPES_H_ */
